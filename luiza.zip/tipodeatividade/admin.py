from django.contrib import admin
from tipodeatividade.models import TipoDeAtividade

# Register your models here.
admin.site.register(TipoDeAtividade)
